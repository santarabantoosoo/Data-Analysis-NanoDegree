Code associated with my YouTube series about Seaborn.  Check out the [full Playlist](https://www.youtube.com/playlist?list=PLtPIclEQf-3cG31dxSMZ8KTcDG7zYng1j). 
